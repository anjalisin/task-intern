# My Chat UI

React + Tailwind starter (Vite)

## To run locally
1. Clone:
   git clone https://github.com/your-username/your-repo.git
2. Install:
   npm install
3. Run dev server:
   npm run dev

## Notes
- If you see Node engine warnings, upgrade Node to v22.x (recommended) or use nvm to switch versions.
- Install dependencies including `lucide-react`, `tailwindcss`, etc., via npm after cloning.
